"use client";
import React, { useState } from 'react';
import Image from 'next/image';

const expertiseData = [
  {
    id: 1,
    category: "Real Estate",
    tagline: "Building Excellence and Empowering Dreams",
    description: "At Tanushree Group, we take immense pride in being more than just a real estate company; we are your trusted partners in building a brighter future. With a history dating back to our inception in 2006, we have become synonymous with innovation, commitment, and excellence in the real estate industry.",
    stats: ["2006 Founded", "100+ Projects", "5000+ Happy Families"],
    color: "#3B82F6",
    icon: (
      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M19 2H9c-1.1 0-2 .9-2 2v6c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 8H9V4h10v6z"/>
        <path d="M15 16H5c-1.1 0-2 .9-2 2v4c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2v-4c0-1.1-.9-2-2-2zm0 6H5v-4h10v4z"/>
        <path d="M3 20H1v-2h2v2z"/>
        <path d="M23 20h-2v-2h2v2z"/>
      </svg>
    ),
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    category: "Education",
    tagline: "Our Educational Journey and Your Bright Future",
    description: "At Tanushree Group, we understand that education is the cornerstone of a prosperous future. Since our establishment in 2006, we've been dedicated to shaping the minds of tomorrow through our innovative and unwavering commitment to education.",
    stats: ["15+ Years Experience", "10,000+ Students", "98% Success Rate"],
    color: "#8B5CF6",
    icon: (
      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 3L1 9l11 6 9-4.91V17h2V9M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z"/>
      </svg>
    ),
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    category: "Hospitality",
    tagline: "Elevate Your Hospitality Experience",
    description: "At Tanushree Group, we believe that hospitality is an art that goes beyond providing a place to stay; it's about creating unforgettable experiences. Since our establishment in 2006, we've been synonymous with excellence in hospitality.",
    stats: ["50+ Properties", "95% Guest Satisfaction", "24/7 Premium Service"],
    color: "#F59E0B",
    icon: (
      <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
        <path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 18H6V4h12v16z"/>
        <path d="M12 6c2.21 0 4 1.79 4 4s-1.79 4-4 4-4-1.79-4-4 1.79-4 4-4zm0 6c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2zm6 5H6v-1.5c0-1.67 3.33-2.5 5-2.5s5 .83 5 2.5V17z"/>
      </svg>
    ),
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  }
];

function OurExpertise() {
  const [hoveredCard, setHoveredCard] = useState(null);
  const [expandedCard, setExpandedCard] = useState(null);

  const toggleExpand = (id) => {
    setExpandedCard(expandedCard === id ? null : id);
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-white via-gray-50 to-white">
      <div className="max-w-7xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-16">
         
          
          <h2 className="text-4xl md:text-4xl font-bold leading-tight text-gray-900 mb-6">
            Building Dreams Across 
            <span className=" ml-2 bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-600 bg-clip-text text-transparent">
              Multiple Verticals
            </span>
          </h2>
          
          <p className="text-gray-600 text-lg max-w-3xl  mx-auto">
            With over 15 years of excellence, Tanushree Group has established itself as a leader 
            across diverse sectors, delivering unparalleled quality and service since 2006.
          </p>
        </div>

        {/* Expertise Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {expertiseData.map((item) => (
            <div
              key={item.id}
              className="group relative bg-white  overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2"
              onMouseEnter={() => setHoveredCard(item.id)}
              onMouseLeave={() => setHoveredCard(null)}
            >
              {/* Card Header with Image */}
              <div className="relative h-64 overflow-hidden">
                <div 
                  className="absolute inset-0 bg-gradient-to-br from-gray-900 to-gray-800 transition-transform duration-700 group-hover:scale-110"
                  style={{
                    backgroundImage: `url(${item.image})`,
                    backgroundSize: 'cover',
                    backgroundPosition: 'center'
                  }}
                >
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t "></div>
                  
             
                  
                  {/* Category Badge */}
                  <div className="absolute bottom-6 left-6">
                    <h3 className="text-2xl font-bold text-white mb-2">
                      {item.category}
                    </h3>
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-8 h-1 rounded-full"
                        style={{ backgroundColor: item.color }}
                      ></div>
                      <span className="text-sm text-gray-300">Since 2006</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card Content */}
              <div className="p-6">
                {/* Tagline */}
                <p className="text-2xl font-semibold text-gray-900 mb-4 leading-relaxed">
                  {item.tagline}
                </p>

                {/* Description */}
                <div className="mb-6">
                  <p className={`text-gray-600  transition-all duration-500 ${
                    expandedCard === item.id ? 'line-clamp-none' : 'line-clamp-3'
                  }`}>
                    {item.description}
                  </p>
                  {!expandedCard === item.id && (
                    <div className="mt-2 text-xs text-gray-400">
                      ...more
                    </div>
                  )}
                </div>


                {/* Action Buttons */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <button
                    onClick={() => toggleExpand(item.id)}
                    className=" font-medium text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-2"
                  >
                    <svg className={`w-5 h-5 transition-transform ${expandedCard === item.id ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                    {expandedCard === item.id ? 'Show Less' : 'Read More'}
                  </button>
                  
                  <button className="group relative px-6 py-2 rounded-lg bg-gradient-to-r from-yellow-400 via-yellow-500 to-amber-500 text-md font-semibold hover:shadow-lg transition-all duration-300 hover:scale-105 overflow-hidden">
                    <span className="relative z-10">Learn More</span>
                    <div className="absolute inset-0 bg-gradient-to-r from-amber-500 via-yellow-500 to-golden opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  </button>
                </div>
              </div>

              {/* Golden Border Effect */}
              <div 
                className={`absolute inset-0 rounded-2xl pointer-events-none transition-opacity duration-500 ${
                  hoveredCard === item.id ? 'opacity-100' : 'opacity-0'
                }`}
                style={{
                  background: `linear-gradient(45deg, ${item.color}20, golden20, ${item.color}20)`,
                  border: `2px solid transparent`,
                  backgroundClip: 'padding-box, border-box',
                  backgroundOrigin: 'border-box'
                }}
              ></div>
            </div>
          ))}
        </div>
      </div>

      
    </section>
  );
}

export default OurExpertise;