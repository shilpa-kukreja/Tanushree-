import React from 'react';

function MissionStats() {
  return (
    <section className="relative bg-white py-16 px-4 md:px-8" style={{ backgroundImage: "url('/assets/img/background/sec-background.png')" }}>
      <div className="max-w-6xl mx-auto">
        
        {/* Mission Statement Section - Top */}
        <div className="mb-6 text-center">
          {/* Mission text block */}
          <div className="">
            <div className="text-xl font-normal text-gray-800 leading-[36px]">
              Our Mission Is Simple Yet Powerful:
            </div>
            
            <h1 className="text-4xl font-bold text-gray-900 ">
              To Redefine What A Workplace Can
            
              <span className="text-yellow-400 ml-1">Be.</span>
            </h1>
          </div>
        </div>

        {/* Main Content Area */}
        <div className=" items-center text-center">
          
          {/* Left Column - Text Content */}
          <div className="space-y-2">
            {/* First paragraph with highlighted "Shainubitz" */}
            <p className="  text-gray-700">
              <span className="font-bold text-gray-900">Shainubitz</span> was created for leaders who refuse to settle - innovations, founders, and visionaries who believe their workspace should elevate their thinking, reflect
            </p>
            
            <p className=" text-gray-700">
              their journey and inspire their future.
            </p>
            
            {/* Second paragraph */}
            <p className=" text-gray-700">
              We are committed to designing environments where ambition meets comfort, productivity meets luxury, and opportunity meets identity. Every detail  from the
            </p>
            
            <p className="leading-[28px] text-gray-700">
              architecture to the amenities  is crafted with intention, purpose, and excellence.
            </p>
            
            {/* Quote section */}
            <div className="mt-4 space-y-2">
              <div className=" text-xl font-light text-gray-800 italic">
                Because Success Deserves More Than Space.
              </div>
              
              <div className="text-2xl  font-bold text-gray-900">
                It Deserves A Stage.
              </div>
            </div>
          </div>

          {/* Right Column - Statistics Grid */}
          <div className="space-y-3 mt-5">
            {/* Top Row - Two Stats */}
            <div className="grid grid-cols-3 text-start gap-6">
              
              {/* AED Stat Box */}
              <div className=" p-6">
                <div className="space-y-4 flex items-center justify-center">
                    <div className='mr-2 mb-0'>
                                <div className="text-3xl font-bold text-gray-900 tracking-tight">
                                    AED
                                </div>
                                <div className="text-3xl font-bold text-gray-900 leading-none">
                                    2.4B+
                                </div>
                    </div>
              
                  <div className="space-y-1">
                    <div className="text-[14px] font-medium text-gray-600 uppercase tracking-[0.2em]">
                      TRANSACTION VALUE
                    </div>
                    <div className="text-[14px] font-medium text-gray-600 uppercase tracking-[0.2em]">
                      GENERATED
                    </div>
                  </div>
                </div>
              </div>
              {/* AED Stat Box */}
              <div className=" p-6">
                <div className="space-y-4 flex items-center justify-center">
                    <div className='mr-2 mb-0'>
                                <div className="text-3xl font-bold text-gray-900 tracking-tight">
                                    AED
                                </div>
                                <div className="text-3xl font-bold text-gray-900 leading-none">
                                    2.4B+
                                </div>
                    </div>
              
                  <div className="space-y-1">
                    <div className="text-[14px] font-medium text-gray-600 uppercase tracking-[0.2em]">
                      TRANSACTION VALUE
                    </div>
                    <div className="text-[14px] font-medium text-gray-600 uppercase tracking-[0.2em]">
                      GENERATED
                    </div>
                  </div>
                </div>
              </div>
              {/* AED Stat Box */}
              <div className=" p-6">
                <div className="space-y-4 flex items-center justify-center">
                    <div className='mr-2 mb-0'>
                                <div className="text-3xl font-bold text-gray-900 tracking-tight">
                                    AED
                                </div>
                                <div className="text-3xl font-bold text-gray-900 leading-none">
                                    2.4B+
                                </div>
                    </div>
              
                  <div className="space-y-1">
                    <div className="text-[14px] font-medium text-gray-600 uppercase tracking-[0.2em]">
                      TRANSACTION VALUE
                    </div>
                    <div className="text-[14px] font-medium text-gray-600 uppercase tracking-[0.2em]">
                      GENERATED
                    </div>
                  </div>
                </div>
              </div>
              
        
            </div>

          </div>
        </div>

      </div>

    
    </section>
  );
}

export default MissionStats;