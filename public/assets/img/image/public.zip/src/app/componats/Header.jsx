"use client";
import Image from 'next/image';
import React, { useState, useEffect } from 'react';

function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Check if scrolled 100vh (viewport height)
      if (window.scrollY > window.innerHeight) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    // Add scroll event listener
    window.addEventListener('scroll', handleScroll);
    
    // Initial check
    handleScroll();

    // Cleanup
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <header 
      className={`fixed w-full top-0 z-50 shadow-2xl backdrop-blur-md transition-all duration-500 ${
        isScrolled 
          ? 'bg-white bg-opacity-95 text-gray-900' 
          : ' text-white'
      } px-6 py-2`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        
        {/* Logo Section */}
        <div className="flex items-center space-x-2">
          <div className="relative  ">
            {/* You'll need to have different logo versions for light/dark */}
            <Image 
              src={isScrolled ? "/assets/img/logo/logo.png" : "/assets/img/logo/logo.png"} 
              alt="logo" 
           
              width={250}
              height={100}
              
              className="w-full"
              
              priority
            />
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center space-x-1">
          {['Home', 'About', 'Services', 'Our Projects', 'Contact'].map((item, index) => (
            <a
              key={index}
              href="#"
              className="group px-5 py-3 relative transition-all duration-300"
            >
              <span className={`group-hover:text-golden transition-colors duration-300 font-medium ${
                index === 0 
                  ? 'text-golden' 
                  : isScrolled 
                    ? 'text-gray-700 hover:text-golden' 
                    : 'text-gray-300 hover:text-golden'
              }`}>
                {item}
              </span>
              <span className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-0.5 bg-gradient-to-r from-golden to-yellow-400 group-hover:w-4/5 transition-all duration-300"></span>
            </a>
          ))}
        </nav>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <button className={`${isScrolled ? 'text-gray-700' : 'text-gray-300'} hover:text-golden`}>
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>

        {/* Golden Premium Button */}
        <button className="group relative px-8 py-3.5 overflow-hidden rounded-xl bg-gradient-to-br from-yellow-400 via-yellow-500 to-amber-600 shadow-lg shadow-yellow-500/30 hover:shadow-yellow-500/50 transition-all duration-500 hover:scale-105">
          
          {/* Button background effects */}
          <div className="absolute inset-0 bg-gradient-to-br from-golden/0 via-yellow-500/0 to-amber-600/0 group-hover:from-golden/20 group-hover:via-yellow-500/20 group-hover:to-amber-600/20 transition-all duration-500"></div>
          
          {/* Shine effect */}
          <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700">
            <div className="w-full h-full bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
          </div>
          
          {/* Button content */}
          <div className="relative flex items-center justify-center space-x-3">
            <span className="font-bold text-gray-900 tracking-wide text-sm">
              GET PREMIUM
            </span>
           
          </div>
        </button>
      </div>
    </header>
  );
}

export default Header;