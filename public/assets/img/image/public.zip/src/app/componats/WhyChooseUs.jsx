import Image from 'next/image';
import React from 'react';

function WhyChooseUsSimple() {
  const features = [
    {
      title: "Diverse Expertise",
      description: "Your one-stop solution across Real Estate, Education, and Hospitality since 2006. Your one-stop solution across Real Estate, Education, and Hospitality since 2006. Your one-stop solution across Real Estate, Education, and Hospitality since 2006.",
      icon: "https://images.unsplash.com/photo-1560518883-ce090…fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "Empowering Dreams",
      description: "Your one-stop solution across Real Estate, Education, and Hospitality since 2006. Your one-stop solution across Real Estate, Education, and Hospitality since 2006. Your one-stop solution across Real Estate, Education, and Hospitality since 2006.",
      icon: "https://images.unsplash.com/photo-1560518883-ce090…fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    },
    {
      title: "Unwavering Support",
      description: "Your one-stop solution across Real Estate, Education, and Hospitality since 2006. Your one-stop solution across Real Estate, Education, and Hospitality since 2006. Your one-stop solution across Real Estate, Education, and Hospitality since 2006.",
      icon: "https://images.unsplash.com/photo-1560518883-ce090…fa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    }
  ];

  return (
    <section className="py-20 px-4 bg-white">
      <div className="max-w-6xl mx-auto">
        
        {/* Simple Header */}
        <div className="text-center mb-7">
          <h2 className="text-4xl font-bold text-gray-900 mb-3">
            Why Choose Us
          </h2>
          <p className="text-gray-600 ">
            Discover what sets us apart in building dreams and creating value
          </p>
        </div>

        {/* Simple Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {features.map((feature, index) => (
            <div key={index} className="bg-gray-50 hover:bg-white hover:shadow-xl transition-all duration-300">
              <Image src="/assets/img/banner/banner.png"  width={100} height={100} alt={feature.title} className="mb-4 w-full" />
              <div className="p-4">
                 <h3 className="text-xl font-bold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 ">
                {feature.description}
              </p>
              </div>
             
            </div>
          ))}
        </div>

 
      </div>
    </section>
  );
}

export default WhyChooseUsSimple;