import Image from 'next/image'
import React from 'react'

function HomeSlider() {
  return (
    <div>
        <Image src="/assets/img/banner/banner.png" alt="slider" width={1920} height={500} />        
    </div>
  )
}

export default HomeSlider
