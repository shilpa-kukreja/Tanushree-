"use client";
import React from 'react';
import Link from 'next/link';

function Footer() {
  return (
    <footer className="relative bg-gradient-to-b from-gray-900 via-gray-900 to-black text-white overflow-hidden">
      
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-0 left-0 w-64 h-64 bg-gradient-to-br from-amber-500/20 to-transparent rounded-full -translate-x-32 -translate-y-32"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-gradient-to-tl from-amber-500/10 to-transparent rounded-full translate-x-48 translate-y-48"></div>
      </div>
      
      {/* Main Content */}
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        {/* Top Section with Logo & Description */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Company Info - Left */}
          <div className="space-y-6">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 bg-gradient-to-br from-amber-500 via-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/20">
                  <span className="text-2xl font-bold text-white">TG</span>
                </div>
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full animate-pulse"></div>
              </div>
              <div>
                <h2 className="text-2xl font-bold bg-gradient-to-r from-white via-amber-200 to-yellow-100 bg-clip-text text-transparent">
                  Tanushree Group
                </h2>
                <p className="text-amber-400 text-sm font-medium">Since 2006</p>
              </div>
            </div>
            
            <p className="text-gray-400 leading-relaxed text-sm">
              We are pioneers in creating exceptional experiences across real estate, 
              education, and hospitality. Building dreams with integrity and innovation 
              for over 15 years.
            </p>
            
            {/* Social Media */}
            <div className="flex gap-3 pt-4">
              {[
                { icon: "F", color: "from-blue-600 to-blue-800", label: "Facebook" },
                { icon: "T", color: "from-sky-500 to-cyan-600", label: "Twitter" },
                { icon: "I", color: "from-pink-500 to-rose-600", label: "Instagram" },
                { icon: "L", color: "from-blue-500 to-indigo-600", label: "LinkedIn" }
              ].map((social) => (
                <a
                  key={social.label}
                  href="#"
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${social.color} flex items-center justify-center text-white shadow-lg hover:shadow-xl hover:scale-110 transition-all duration-300 group`}
                  aria-label={social.label}
                >
                  <span className="font-bold group-hover:scale-110 transition-transform">{social.icon}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links - Center Left */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative inline-block">
              <span className="relative z-10">Quick Links</span>
              <div className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full"></div>
            </h3>
            <ul className="space-y-4">
              {["Home", "About Us", "Services", "Our Projects", "Contact Us"].map((item) => (
                <li key={item}>
                  <Link 
                    href="#" 
                    className="flex items-center gap-3 text-gray-400 hover:text-amber-300 transition-all duration-300 group"
                  >
                    <div className="w-2 h-2 bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transform group-hover:scale-150 transition-transform"></div>
                    <span className="group-hover:translate-x-2 transition-transform">{item}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Our Verticals - Center Right */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative inline-block">
              <span className="relative z-10">Our Verticals</span>
              <div className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-full"></div>
            </h3>
            <ul className="space-y-4">
              {[
                { name: "Real Estate", color: "from-blue-500 to-cyan-400" },
                { name: "Education", color: "from-purple-500 to-pink-400" },
                { name: "Hospitality", color: "from-amber-500 to-orange-400" }
              ].map((vertical) => (
                <li key={vertical.name}>
                  <Link 
                    href="#" 
                    className="flex items-center gap-3 text-gray-400 hover:text-white transition-all duration-300 group"
                  >
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${vertical.color} flex items-center justify-center text-white text-sm font-bold`}>
                      {vertical.name.charAt(0)}
                    </div>
                    <span className="group-hover:translate-x-2 transition-transform">{vertical.name}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info - Right */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative inline-block">
              <span className="relative z-10">Get In Touch</span>
              <div className="absolute -bottom-1 left-0 w-full h-1 bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"></div>
            </h3>
            <div className="space-y-6">
              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-white">Our Location</p>
                  <p className="text-gray-400 text-sm mt-1">123 Business District, Mumbai, Maharashtra 400001</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-white">Call Us</p>
                  <p className="text-gray-400 text-sm mt-1">+91 22 1234 5678</p>
                  <p className="text-amber-400 text-sm mt-2 font-medium">24/7 Support Available</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4 group">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform">
                  <svg className="w-6 h-6 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 4.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <p className="font-medium text-white">Email Us</p>
                  <p className="text-gray-400 text-sm mt-1">contact@tanushreegroup.com</p>
                  <p className="text-amber-400 text-sm mt-2 font-medium">Response within 24 hours</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Divider with Gradient */}
        <div className="relative h-px mb-12">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-amber-500/30 to-transparent"></div>
        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          
          {/* Copyright */}
          <div className="text-center md:text-left">
            <p className="text-gray-400 text-sm">
              © {new Date().getFullYear()} <span className="text-amber-400 font-medium">Tanushree Group</span>. All rights reserved.
            </p>
            <p className="text-gray-500 text-xs mt-2">Pioneering Excellence Since 2006</p>
          </div>
          
          {/* Legal Links */}
          <div className="flex flex-wrap justify-center gap-6">
            {["Privacy Policy", "Terms of Service", "Cookie Policy", "Disclaimer", "Sitemap"].map((link) => (
              <Link
                key={link}
                href="#"
                className="text-gray-400 hover:text-amber-300 text-sm transition-colors relative group"
              >
                {link}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-amber-400 to-yellow-300 group-hover:w-full transition-all duration-300"></span>
              </Link>
            ))}
          </div>
          
          {/* Back to Top */}
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="group relative px-6 py-3 rounded-xl bg-gradient-to-br from-gray-800 to-gray-900 hover:from-gray-700 hover:to-gray-800 transition-all duration-300 flex items-center gap-2 shadow-lg hover:shadow-xl"
          >
            <span className="text-gray-300 group-hover:text-white">Back to Top</span>
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500 to-yellow-400 flex items-center justify-center group-hover:scale-110 transition-transform">
              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
              </svg>
            </div>
          </button>
        </div>

  
      </div>

      {/* Floating Decorative Elements */}
      <div className="absolute bottom-4 left-4 w-4 h-4 bg-gradient-to-br from-amber-500/20 to-transparent rounded-full animate-pulse"></div>
      <div className="absolute top-4 right-4 w-6 h-6 bg-gradient-to-br from-yellow-500/10 to-transparent rounded-full animate-pulse delay-300"></div>
      <div className="absolute top-1/3 left-1/4 w-3 h-3 bg-gradient-to-br from-orange-500/15 to-transparent rounded-full animate-pulse delay-500"></div>
    </footer>
  );
}

export default Footer;