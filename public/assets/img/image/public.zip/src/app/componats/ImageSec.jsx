import Image from 'next/image'
import React from 'react'

function ImageSec({img = null}) {
  return (
    <div>
        <Image src={img} alt="slider" width={1920} height={500} />
    </div>
  )
}

export default ImageSec
