import AboutUs from "./componats/AboutUs";
import Footer from "./componats/Footer";
import Header from "./componats/Header";
import HomeSlider from "./componats/HomeSlider";
import ImageSec from "./componats/ImageSec";
import MissionStats from "./componats/MissionStats";
import OurExpertise from "./componats/OurExpertise";
import OurProjects from "./componats/OurProjects";
import ReviewsSection from "./componats/ReviewsSection";
import WhyChooseUs from "./componats/WhyChooseUs";


export default function Home() {
  return (
    <div className="">
      <Header />
      <HomeSlider />
      <AboutUs />
      <ImageSec img={"/assets/img/banner/banner.png"} />
      <OurExpertise />
      <ImageSec img={"/assets/img/banner/banner.png"} />
      <MissionStats />
      <ImageSec img={"/assets/img/banner/banner.png"} />
      <WhyChooseUs />
      <ImageSec img={"/assets/img/banner/banner.png"} />
      <ReviewsSection />
      <ImageSec img={"/assets/img/banner/banner.png"} />
      <OurProjects />
      <ImageSec img={"/assets/img/banner/banner.png"} />
      <Footer />
    </div>
  );
}
